﻿Place multilingual terms here: Elvora_Terms_Multilingual.pdf
