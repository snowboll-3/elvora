﻿U ovu mapu kopiraj PNG-ove s točnim nazivima:
- tile-stanje.png, tile-ulaz.png, tile-izlaz.png, tile-trazi.png
- ph-stanje.png, ph-ulaz.png, ph-izlaz.png, ph-trazi.png
- screen-stanje.png, screen-ulaz.png, screen-izlaz.png, screen-trazi.png
