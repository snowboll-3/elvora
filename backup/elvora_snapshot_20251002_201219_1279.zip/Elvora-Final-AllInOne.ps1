﻿$ErrorActionPreference="Stop"
$root = "elvora/public"
$media = Join-Path $root "media"
New-Item -ItemType Directory -Force -Path $media | Out-Null

# 1) PLACEHOLDERI
$r1=[byte[]](1..100); Set-Content (Join-Path $media "hero-demo.mp4") -Value $r1 -Encoding Byte
$r2=[byte[]](1..100); Set-Content (Join-Path $root  "og-image.png")  -Value $r2 -Encoding Byte
$r3=[byte[]](1..100); Set-Content (Join-Path $root  "favicon.ico")   -Value $r3 -Encoding Byte
$r4=[byte[]](1..100); Set-Content (Join-Path $root  "apple-touch-icon.png") -Value $r4 -Encoding Byte

# 2) STILOVI
$stylesPath = Join-Path $root "styles.css"
New-Item -ItemType File -Force -Path $stylesPath | Out-Null
$css = Get-Content $stylesPath -Raw
if ($css -notmatch "--focus") {
$css += @"

:root{ --focus: #37c0ff }
:focus-visible{ outline:2px solid var(--focus); outline-offset:2px }
.hero video{ width:100%; max-width:720px; border-radius:16px; border:1px solid var(--line); background:#000 }
.subtext{ color:var(--muted); margin-top:6px }
"@
Set-Content $stylesPath -Value $css -Encoding UTF8
}

# 3) INDEX.HTML (landing)
$indexPath = Join-Path $root "index.html"
New-Item -ItemType File -Force -Path $indexPath | Out-Null
$idx = @"
<!doctype html><html lang="hr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Elvora – AI Scan • Track • Predict</title>
<meta name="description" content="Elvora – PWA za skeniranje, inventuru, logistiku i HACCP.">
<link rel="icon" href="/favicon.ico">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="stylesheet" href="/styles.css">
</head><body>
<header><div class="container nav"><div class="brand">Elvora</div><nav><a class="btn" href="/products/">Naši proizvodi</a></nav></div></header>
<main class="container">
  <section class="hero">
    <h1>AI Scan • Track • Predict</h1>
    <p class="subtext">Pametno upravljanje inventurom, logistikom i HACCP-om.</p>
    <video src="/media/hero-demo.mp4" autoplay muted loop playsinline></video>
  </section>
</main>
<footer><div class="container rights">© <span id="y"></span> Elvora. Sva prava pridržana.</div></footer>
<script>document.getElementById('y').textContent=new Date().getFullYear()</script>
</body></html>
"@
Set-Content $indexPath -Value $idx -Encoding UTF8

Write-Host "✅ All-in-One setup kreiran (landing, stilovi, media placeholderi)" -ForegroundColor Green
